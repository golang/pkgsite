package p

// V is a variable.
var V = 1
