package foo

// Foo returns the string "foo".
func Foo() string {
	return "foo"
}
