package bar

// Bar returns the string "bar".
func Bar() string {
	return "bar"
}
