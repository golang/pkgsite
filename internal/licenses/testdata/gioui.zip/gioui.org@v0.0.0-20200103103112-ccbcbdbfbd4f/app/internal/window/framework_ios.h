// SPDX-License-Identifier: Unlicense OR MIT

#include <UIKit/UIKit.h>

@interface GioAppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

