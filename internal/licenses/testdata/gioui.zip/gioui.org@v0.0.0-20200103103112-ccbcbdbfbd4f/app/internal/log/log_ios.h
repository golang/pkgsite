// SPDX-License-Identifier: Unlicense OR MIT

__attribute__ ((visibility ("hidden"))) void nslog(char *str);
