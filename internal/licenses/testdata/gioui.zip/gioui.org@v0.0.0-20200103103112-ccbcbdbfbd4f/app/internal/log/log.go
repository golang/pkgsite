// SPDX-License-Identifier: Unlicense OR MIT

// Package points standard output, standard error and the standard
// library package log to the platform logger.
package log
